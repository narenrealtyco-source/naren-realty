import { requireAdmin } from "./supabase-server";
import type { EnquiryRecord } from "./enquiries";

const PROPERTY_COLUMNS = [
  "id",
  "owner_id",
  "title",
  "category",
  "locality",
  "price",
  "details",
  "photos",
  "status",
  "created_at",
  "updated_at",
] as const;

export type AdminPropertyRecord = {
  id: string;
  owner_id: string;
  title: string;
  category: string;
  locality: string;
  price: number;
  details: unknown;
  photos: unknown;
  status: string;
  created_at: string;
  updated_at: string;
};

export type AdminDashboardStats = {
  totalProperties: number;
  pendingProperties: number;
  approvedProperties: number;
  rejectedProperties: number;
  totalEnquiries: number;
  newEnquiries: number;
  dealClosedEnquiries: number;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringField(row: Record<string, unknown>, field: string): string {
  const value = row[field];
  if (typeof value !== "string") {
    throw new Error(`Admin property data has an invalid "${field}" value.`);
  }
  return value;
}

function numberField(row: Record<string, unknown>, field: string): number {
  const value = row[field];
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(number)) {
    throw new Error(`Admin property data has an invalid "${field}" value.`);
  }
  return number;
}

function mapProperty(row: unknown): AdminPropertyRecord {
  if (!isRecord(row)) {
    throw new Error("Supabase returned an invalid admin property record.");
  }

  return {
    id: stringField(row, "id"),
    owner_id: stringField(row, "owner_id"),
    title: stringField(row, "title"),
    category: stringField(row, "category"),
    locality: stringField(row, "locality"),
    price: numberField(row, "price"),
    details: row.details,
    photos: row.photos,
    status: stringField(row, "status"),
    created_at: stringField(row, "created_at"),
    updated_at: stringField(row, "updated_at"),
  };
}

export async function getAdminPropertiesFromSupabase(): Promise<AdminPropertyRecord[]> {
  const { supabase } = await requireAdmin();
  const { data, error } = await supabase
    .from("properties")
    .select(PROPERTY_COLUMNS.join(","));

  if (error) {
    throw new Error(`Could not load admin properties from Supabase: ${error.message}`);
  }

  return (data ?? []).map(mapProperty);
}

export async function getAdminEnquiriesFromSupabase(): Promise<EnquiryRecord[]> {
  const { supabase } = await requireAdmin();
  const { data, error } = await supabase
    .from("enquiries")
    .select("id,customer_id,property_id,customer_name,customer_phone,requirement,message,status,admin_notes,follow_up_date,created_at");

  if (error) {
    throw new Error(`Could not load admin enquiries from Supabase: ${error.message}`);
  }

  return (data ?? []).map(mapEnquiry);
}

export async function getAdminDashboardStatsFromSupabase(): Promise<AdminDashboardStats> {
  await requireAdmin();
  const [properties, enquiries] = await Promise.all([
    getAdminPropertiesFromSupabase(),
    getAdminEnquiriesFromSupabase(),
  ]);
  const isApproved = (status: string) => status.toLowerCase() === "approved";
  const isRejected = (status: string) => status.toLowerCase() === "rejected";
  const isPending = (status: string) => {
    const normalized = status.toLowerCase();
    return normalized === "pending" || normalized === "pending approval";
  };

  return {
    totalProperties: properties.length,
    pendingProperties: properties.filter((property) => isPending(property.status)).length,
    approvedProperties: properties.filter((property) => isApproved(property.status)).length,
    rejectedProperties: properties.filter((property) => isRejected(property.status)).length,
    totalEnquiries: enquiries.length,
    newEnquiries: enquiries.filter((enquiry) => enquiry.status === "New").length,
    dealClosedEnquiries: enquiries.filter((enquiry) => enquiry.status === "Deal Closed").length,
  };
}

function nullableString(value: unknown): string | undefined {
  return value === null || value === undefined ? undefined : typeof value === "string" ? value : undefined;
}

function enquiryStatus(value: unknown): EnquiryRecord["status"] {
  if (typeof value !== "string") {
    throw new Error("Supabase returned an enquiry with an invalid status.");
  }
  const statuses = [
    "New",
    "Contacted",
    "Owner Confirmation",
    "Visit Scheduled",
    "Visit Completed",
    "Negotiation",
    "Deal Closed",
    "Lost",
  ] as const;
  if (!statuses.includes(value as (typeof statuses)[number])) {
    throw new Error(`Supabase returned an unsupported enquiry status: "${value}".`);
  }
  return value as EnquiryRecord["status"];
}

function enquiryRequirement(value: unknown): EnquiryRecord["requirement"] {
  if (value === null || value === undefined || value === "") return "";
  if (value === "Rental" || value === "Resale" || value === "PG" || value === "Airbnb") return value;
  throw new Error(`Supabase returned an unsupported enquiry requirement: "${String(value)}".`);
}

function mapEnquiry(value: Record<string, unknown>): EnquiryRecord {
  const id = nullableString(value.id);
  const customerId = nullableString(value.customer_id);
  if (!id || !customerId) {
    throw new Error("Supabase returned an enquiry without a valid ID or customer ID.");
  }

  return {
    id,
    customerId,
    listingId: nullableString(value.property_id),
    fullName: nullableString(value.customer_name) ?? "Unknown customer",
    mobileNumber: nullableString(value.customer_phone) ?? "",
    requirement: enquiryRequirement(value.requirement),
    message: nullableString(value.message) ?? "",
    propertyName: nullableString(value.property_id) ?? "Property not specified",
    locality: "Not provided",
    status: enquiryStatus(value.status),
    adminCallNotes: nullableString(value.admin_notes),
    nextFollowUpDate: nullableString(value.follow_up_date)?.slice(0, 10),
    createdAt: nullableString(value.created_at) ?? "",
  };
}
