"use client";

import { additionalFields, amenitiesForCategory, commonFields, pgFacilities, sharingFields } from "./additional-fields";
import type { SubmissionDetails } from "../lib/submission-details";

const labelClass = "block text-sm font-semibold text-slate-900";
const inputClass = "mt-2 block min-w-0 w-full max-w-full rounded-lg border border-slate-400 bg-white px-4 py-3 text-base font-normal text-slate-950";

export function emptyDetails(): SubmissionDetails {
  return { version: 1, values: {}, amenities: {}, facilities: [] };
}

export default function AdditionalDetails({ category, details, onChange }: {
  category: string; details: SubmissionDetails; onChange: (value: SubmissionDetails) => void;
}) {
  function fields(items: typeof commonFields, scope: string) {
    return items.map((field) => {
      const key = `${scope}_${field.key}`;
      const change = (value: string) => onChange({ ...details, values: { ...details.values, [key]: value } });
      return <label key={key} className={labelClass}>{field.label}
        {field.options ? <select value={details.values[key] ?? ""} onChange={(event) => change(event.target.value)} className={inputClass}><option value="">Not selected</option>{field.options.map((option) => <option key={option}>{option}</option>)}</select>
          : <input type={field.type ?? "text"} min={field.type === "number" ? 0 : undefined} step={field.type === "number" ? "any" : undefined} maxLength={2000} value={details.values[key] ?? ""} onChange={(event) => change(event.target.value)} className={inputClass} />}
      </label>;
    });
  }
  function choices(options: string[], selected: string[], update: (values: string[]) => void) {
    return <div className="mt-4 grid gap-2 sm:grid-cols-2">{options.map((choice) => <label key={choice} className="flex items-start gap-3 rounded-lg border border-slate-300 bg-white px-3 py-3 text-sm font-medium text-slate-900"><input type="checkbox" checked={selected.includes(choice)} onChange={(event) => update(event.target.checked ? [...selected, choice] : selected.filter((item) => item !== choice))} className="mt-0.5 size-4 accent-[#10243A]" />{choice}</label>)}</div>;
  }
  return <section className="min-w-0 space-y-4 rounded-lg border border-amber-300 bg-amber-50 p-4">
    <h3 className="text-lg font-bold text-[#10243A]">Additional property details</h3>
    <p className="text-sm text-slate-900">Details entered for other categories are retained if you switch categories.</p>
    <div className="grid gap-4 sm:grid-cols-2">{fields(commonFields, "common")}{fields(additionalFields(category), category)}</div>
    {category === "PG" && <fieldset className="min-w-0"><legend className="font-bold">Sharing options: enter details for each available option</legend><div className="grid gap-4 sm:grid-cols-2">{fields(sharingFields, "PG")}</div></fieldset>}
    {category && <fieldset className="min-w-0"><legend className="font-bold">Available amenities</legend>{choices(amenitiesForCategory(category), details.amenities[category] ?? [], (values) => onChange({ ...details, amenities: { ...details.amenities, [category]: values } }))}</fieldset>}
    {category === "PG" && <fieldset className="min-w-0"><legend className="font-bold">PG facilities</legend>{choices(pgFacilities, details.facilities, (facilities) => onChange({ ...details, facilities }))}</fieldset>}
    <input type="hidden" name="details" value={JSON.stringify(details)} />
  </section>;
}
