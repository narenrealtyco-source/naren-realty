"use client";

import { useState } from "react";
import Link from "next/link";
import type { PropertyListing } from "../lib/properties";
import { propertyBadge } from "../lib/property-marketing";
import FavoriteButton from "./FavoriteButton";
import ContactButton from "./ContactButton";
import VisitRequestForm from "../properties/[id]/VisitRequestForm";

export default function PropertyCard({ listing, listings, visitsReady }: { listing: PropertyListing; listings: PropertyListing[]; visitsReady: boolean }) {
  const [visitOpen, setVisitOpen] = useState(false);
  const category = { Rental: "Flat Rental", Resale: "Flat Resale", PG: "PG / Hostel", Airbnb: "Airbnb / Short Stay" }[listing.type];
  const suffix = { Rental: " / month", Resale: "", PG: " / person / month", Airbnb: " / night" }[listing.type];
  const price = `₹${listing.price.toLocaleString("en-IN")}${suffix}`;
  const details = [listing.bedrooms ? `${listing.bedrooms} bedrooms` : "", listing.area ? `${listing.area} sq. ft.` : "", listing.furnishing].filter(Boolean).join(" · ");
  const badge = propertyBadge(listing, listings);
  return <article className="flex h-full flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
    <div className="relative">
      <Link href={`/properties/${listing.id}`} aria-label={`View ${listing.title}`} className="block">
        {listing.photos[0] ? <img src={listing.photos[0]} alt={listing.title} width={800} height={600} loading="lazy" decoding="async" className="aspect-[4/3] w-full object-cover" /> : <div className="flex aspect-[4/3] items-center justify-center bg-slate-100 text-sm text-slate-600">Photo unavailable</div>}
      </Link>
      {badge && <span className="absolute left-3 top-3 max-w-[65%] rounded-md bg-amber-400 px-3 py-1.5 text-xs font-bold text-slate-950 shadow">{badge}</span>}
      <div className="absolute right-3 top-3"><FavoriteButton propertyId={listing.id} title={listing.title} locality={listing.locality} type={category} price={price} bedrooms={listing.bedrooms || undefined} /></div>
    </div>
    <div className="flex flex-1 flex-col p-5">
      <p className="text-xs font-bold uppercase tracking-wider text-amber-700">{category}</p>
      <h3 className="mt-2 break-words text-lg font-bold text-[#10243A]"><Link href={`/properties/${listing.id}`} className="hover:underline">{listing.title}</Link></h3>
      <p className="mt-1 break-words text-sm text-slate-600">{listing.locality}, Pune</p>
      {details && <p className="mt-2 text-sm text-slate-700">{details}</p>}
      <p className="mt-3 font-bold text-[#10243A]">{price}</p>
      <div className="mt-auto pt-4">
        <button type="button" disabled={!visitsReady} onClick={() => setVisitOpen(true)} className="w-full rounded-lg bg-[#10243A] px-4 py-3 text-sm font-bold text-white hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-50">Schedule Visit</button>
        {!visitsReady && <p className="mt-1 text-xs text-slate-600">Visit requests are not available yet.</p>}
        <div className="mt-3"><ContactButton /></div>
      </div>
    </div>
    {visitOpen && <VisitRequestForm propertyId={listing.id} title={listing.title} onClose={() => setVisitOpen(false)} />}
  </article>;
}
