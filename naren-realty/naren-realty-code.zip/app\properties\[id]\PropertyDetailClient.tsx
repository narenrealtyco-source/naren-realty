"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import ContactButton from "../../components/ContactButton";
import VisitRequestForm from "./VisitRequestForm";
import FavoriteButton from "../../components/FavoriteButton";
import { type PropertyListing } from "../../lib/properties";
import { loadApprovedProperties } from "../actions";
import { visitRequestsReady } from "../visit-actions";
import SavedDetails from "../../list-property/SavedDetails";

export default function PropertyDetailClient({ listingId }: { listingId: string }) {
  const [listing, setListing] = useState<PropertyListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [photoIndex, setPhotoIndex] = useState(0);
  const [visitOpen, setVisitOpen] = useState(false);
  const [visitsReady, setVisitsReady] = useState(false);

  useEffect(() => {
    let active = true;
    visitRequestsReady().then((ready) => { if (active) setVisitsReady(ready); }).catch(() => { if (active) setVisitsReady(false); });
    loadApprovedProperties().then((items) => { if (active) setListing(items.find((property) => property.id === listingId) ?? null); })
      .catch(() => { if (active) setLoadError("Property could not be loaded. Please try again."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [listingId]);

  const details = listing?.categoryDetails as Record<string, unknown> | undefined;
  const displayPrice = listing
    ? listing.type === "Rental" ? Number(details?.monthlyRent ?? listing.price)
      : listing.type === "Resale" ? Number(details?.expectedSalePrice ?? listing.price)
        : listing.type === "Airbnb" ? Number(details?.pricePerNight ?? listing.price)
          : listing.price
    : 0;
  const priceSuffix = listing?.type === "Rental" ? " / month" : listing?.type === "PG" ? " / person / month" : listing?.type === "Airbnb" ? " / night" : "";
  const categoryLabel = listing?.type === "Rental" ? "Flat Rental" : listing?.type === "Resale" ? "Flat Resale" : listing?.type === "PG" ? "PG / Hostel" : "Airbnb / Short Stay";

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-[#10243A] text-white"><div className="mx-auto flex max-w-7xl items-center justify-between gap-2 px-4 py-4 sm:gap-4 sm:px-6 sm:py-5"><Link href="/" className="text-base font-bold tracking-wide sm:text-xl sm:tracking-widest">NAREN <span className="text-amber-400">REALTY</span></Link><Link href="/properties" className="shrink-0 rounded-lg border border-amber-400 px-3 py-3 text-xs font-semibold text-amber-400 sm:px-4 sm:text-sm">Browse Properties</Link></div></header>
      <section className="mx-auto max-w-6xl px-5 py-8 sm:px-6 sm:py-12">
        <Link href="/properties" className="text-sm font-semibold text-[#10243A] hover:text-amber-700">&larr; All approved properties</Link>
        {loading ? <p className="mt-8 text-slate-600">Loading property...</p> : loadError ? <p role="alert" className="mt-8 text-rose-700">{loadError}</p> : !listing ? <div className="mt-8 border-y border-slate-200 py-14"><h1 className="text-2xl font-bold text-[#10243A]">Property unavailable</h1><p className="mt-2 text-slate-600">This property may no longer be approved for browsing.</p></div> : <div className="mt-6 grid gap-8 lg:grid-cols-[1.25fr_0.75fr]">
          <div>
            <div className="overflow-hidden rounded-lg bg-[#10243A]">{listing.photos[photoIndex] ? <img src={listing.photos[photoIndex]} alt={`${listing.title}, photo ${photoIndex + 1}`} width={1200} height={900} decoding="async" className="aspect-[4/3] w-full object-cover" /> : <div className="flex aspect-[4/3] items-center justify-center text-6xl text-amber-400">⌂</div>}</div>
            {listing.photos.length > 1 && <div className="mt-3 grid grid-cols-5 gap-2">{listing.photos.map((photo, index) => <button key={`${listing.id}-${index}`} onClick={() => setPhotoIndex(index)} aria-label={`View photo ${index + 1}`} aria-pressed={photoIndex === index} className={`overflow-hidden rounded-md border-2 ${photoIndex === index ? "border-amber-500" : "border-transparent"}`}><img src={photo} alt="" width={160} height={160} loading="lazy" decoding="async" className="aspect-square w-full object-cover" /></button>)}</div>}
            <div className="mt-7 min-w-0 border-t border-slate-200 pt-6 [overflow-wrap:anywhere]"><p className="text-xs font-bold uppercase tracking-wider text-amber-700">{categoryLabel}</p>{Boolean(listing.area) && <p className="mt-3 text-slate-700">Area: {listing.area} sq. ft.</p>}{Boolean(listing.bedrooms) && <p className="mt-2 text-slate-700">Bedrooms: {listing.bedrooms}</p>}{Boolean(listing.bathrooms) && <p className="mt-2 text-slate-700">Bathrooms: {listing.bathrooms}</p>}{listing.furnishing && <p className="mt-2 text-slate-700">Furnishing: {listing.furnishing}</p>}{listing.address && <p className="mt-3 whitespace-pre-wrap">Address: {listing.address}</p>}{listing.description && <p className="mt-3 whitespace-pre-wrap">{listing.description}</p>}{listing.publicListingDetails && <SavedDetails value={listing.publicListingDetails} />}</div>
          </div>
          <aside className="min-w-0 self-start rounded-lg border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><p className="text-xs font-bold uppercase tracking-wider text-amber-700">Naren Realty approved</p><h1 className="mt-2 break-words text-2xl font-bold text-[#10243A]">{listing.title}</h1><p className="mt-2 break-words text-slate-600">{listing.locality}, Pune</p><p className="mt-5 text-2xl font-bold text-[#10243A]">₹{displayPrice.toLocaleString("en-IN")}<span className="text-sm font-medium text-slate-600">{priceSuffix}</span></p><div className="mt-6 flex flex-wrap items-center gap-3"><FavoriteButton propertyId={listing.id} title={listing.title} locality={listing.locality} type={categoryLabel} price={`₹${displayPrice.toLocaleString("en-IN")}${priceSuffix}`} bedrooms={listing.bedrooms || undefined} /><ContactButton /><button disabled={!visitsReady} onClick={() => setVisitOpen(true)} className="min-w-[10rem] flex-1 rounded-lg bg-amber-400 px-5 py-3 font-bold text-slate-950 hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50">Schedule Visit</button></div><p className="mt-3 text-xs leading-5 text-slate-500">{visitsReady ? "Visit requests are subject to confirmation." : "Visit requests are not available yet."} Owner contact details are not displayed.</p></aside>
        </div>}
      </section>
      {visitOpen && listing && <VisitRequestForm propertyId={listing.id} title={listing.title} onClose={() => setVisitOpen(false)} />}
    </main>
  );
}
