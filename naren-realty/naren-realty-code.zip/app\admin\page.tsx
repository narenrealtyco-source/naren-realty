"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import AdminLogoutButton from "../components/AdminLogoutButton";
import { loadAdminDashboardStats } from "./actions";
import type { AdminDashboardStats } from "../lib/admin-supabase-data";

type DashboardStat = {
  label: string;
  value: number;
  href: string;
  color: string;
};

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    loadAdminDashboardStats()
      .then((nextStats) => {
        if (active) {
          setStats(nextStats);
          setError("");
        }
      })
      .catch((loadError: unknown) => {
        if (active) setError(loadError instanceof Error ? loadError.message : "Dashboard data could not be loaded.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const dashboardStats: DashboardStat[] = stats ? [
    { label: "Total Properties", value: stats.totalProperties, href: "/admin/properties", color: "border-[#10243A]" },
    { label: "Pending Approvals", value: stats.pendingProperties, href: "/admin/properties?status=pending", color: "border-amber-500" },
    { label: "Approved Properties", value: stats.approvedProperties, href: "/admin/properties?status=approved", color: "border-emerald-600" },
    { label: "Rejected Properties", value: stats.rejectedProperties, href: "/admin/properties?status=rejected", color: "border-rose-600" },
    { label: "Total Enquiries", value: stats.totalEnquiries, href: "/admin/enquiries", color: "border-[#10243A]" },
    { label: "New Enquiries", value: stats.newEnquiries, href: "/admin/enquiries?status=New", color: "border-amber-500" },
    { label: "Deals Closed", value: stats.dealClosedEnquiries, href: "/admin/enquiries?status=Deal%20Closed", color: "border-emerald-600" },
  ] : [];

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-[#10243A] text-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-5 sm:px-6 md:flex-row md:items-center md:justify-between">
          <div><p className="text-xs font-bold tracking-[0.18em] text-amber-400">NAREN REALTY</p><h1 className="mt-1 text-xl font-bold">Admin Dashboard</h1></div>
          <nav aria-label="Admin navigation" className="flex flex-wrap gap-2 text-sm">
            <Link href="/admin/properties/new" className="rounded-md bg-amber-400 px-3 py-2 font-bold text-slate-950">Add Property</Link>
            <Link href="/admin/properties" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Properties</Link>
            <Link href="/admin/enquiries" className="rounded-md border border-amber-400 bg-amber-400 px-3 py-2 font-semibold text-slate-950">Enquiries</Link>
            <Link href="/admin/visits" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Visit Requests</Link>
            <Link href="/admin/submissions" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Submissions</Link>
            <Link href="/admin/services" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Home Services</Link>
            <Link href="/admin/requirements" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Requirements</Link>
            <Link href="/admin/policies" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Policies</Link>
            <Link href="/" className="rounded-md border border-white/30 px-3 py-2 font-semibold hover:bg-white/10">Website</Link>
            <AdminLogoutButton />
          </nav>
        </div>
      </header>
      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-6 sm:py-12">
        <div className="border-b border-slate-200 pb-6"><p className="text-xs font-bold tracking-[0.18em] text-amber-700">OPERATIONS OVERVIEW</p><h2 className="mt-2 text-3xl font-bold text-[#10243A]">Dashboard</h2><p className="mt-2 text-sm text-slate-600">Current totals from Supabase.</p></div>
        {loading && <p role="status" className="mt-5 text-sm text-slate-600">Loading dashboard statistics...</p>}
        {error && <p role="alert" className="mt-5 text-sm text-rose-700">{error}</p>}
        {!loading && !error && stats && dashboardStats.length > 0 && <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{dashboardStats.map((stat) => <Link key={stat.label} href={stat.href} className={`rounded-lg border border-slate-200 border-l-4 ${stat.color} bg-white p-5 shadow-sm transition hover:border-amber-400`}><p className="text-sm font-semibold text-slate-600">{stat.label}</p><p className="mt-3 text-3xl font-bold text-[#10243A]">{stat.value}</p></Link>)}</div>}
        {!loading && !error && stats && stats.totalProperties === 0 && stats.totalEnquiries === 0 && <p role="status" className="mt-6 text-sm text-slate-600">No Supabase properties or enquiries were found.</p>}
      </section>
    </main>
  );
}
