export function propertySubmissionsEnabled(): boolean {
  return process.env.PROPERTY_SUBMISSIONS_ENABLED === "true";
}

export function propertySubmissionUploadsReady(): boolean {
  return false;
}
