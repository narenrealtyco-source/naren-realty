import { AIRBNB_AMENITIES, FLAT_AMENITIES, PG_AMENITIES, type ListingType } from "../lib/properties";

export type AdditionalField = { key: string; label: string; type?: "number" | "date" | "time"; options?: string[] };

export const pgFacilities = ["Food Included", "Electricity Included", "Wi-Fi Included", "Maintenance Included", "Attached Bathroom", "AC Available", "Laundry Included", "Housekeeping Included"];
export const sharingTypes = ["Single Sharing (1 Person)", "Double Sharing (2 Persons)", "Triple Sharing (3 Persons)", "Four Sharing (4 Persons)", "Five Sharing (5 Persons)", "Dormitory (Multiple Sharing)", "Private Room"];

export const commonFields: AdditionalField[] = [
  { key: "property_type", label: "Property type", options: ["Apartment / Flat", "House / Villa", "PG / Hostel", "Short stay", "Other"] },
  { key: "purpose", label: "Listing purpose", options: ["Rent", "Resale", "New Property", "PG", "Short Stay"] },
  { key: "landmark", label: "Landmark" },
  { key: "available_from", label: "Available from", type: "date" },
  { key: "built_up_area", label: "Built-up area (sq. ft.)", type: "number" },
];

const flatFields: AdditionalField[] = [
  { key: "bhk", label: "BHK configuration", options: ["1 RK", "1 BHK", "2 BHK", "3 BHK", "4 BHK", "5 BHK"] },
  { key: "bedrooms", label: "Bedrooms", type: "number" },
  { key: "bathrooms", label: "Bathrooms", type: "number" },
  { key: "balconies", label: "Balconies", type: "number" },
  { key: "floor", label: "Floor number", type: "number" },
  { key: "total_floors", label: "Total floors", type: "number" },
  { key: "furnishing", label: "Furnishing", options: ["Unfurnished", "Semi-Furnished", "Fully Furnished"] },
  { key: "age", label: "Property age", options: ["New / Ready to Move", "1–5 Years", "5–10 Years", "10+ Years"] },
  { key: "entry", label: "Main entry direction", options: ["North", "South", "East", "West", "North-East", "North-West", "South-East", "South-West"] },
  { key: "exit", label: "Exit direction", options: ["North", "South", "East", "West", "North-East", "North-West", "South-East", "South-West"] },
];

const rentalFields: AdditionalField[] = [
  { key: "deposit", label: "Security deposit (INR)", type: "number" },
  { key: "negotiable", label: "Rent negotiable", options: ["Yes", "No"] },
  { key: "maintenance_included", label: "Maintenance included", options: ["Yes", "No"] },
  { key: "maintenance", label: "Monthly maintenance charges (INR)", type: "number" },
  { key: "parking_charges", label: "Parking charges (INR)", type: "number" },
  { key: "tenant_preference", label: "Tenant preference", options: ["Family", "Bachelor", "Working Professionals", "Any"] },
];
const resaleFields: AdditionalField[] = [
  { key: "negotiable", label: "Price negotiable", options: ["Yes", "No"] },
  { key: "parking_details", label: "Parking details" },
  { key: "ownership", label: "Ownership type" },
  { key: "possession", label: "Possession status" },
];
const pgFields: AdditionalField[] = [
  { key: "rooms", label: "Total rooms", type: "number" },
  { key: "gender", label: "Gender preference", options: ["Boys", "Girls", "Co-Living"] },
  { key: "suitable", label: "Suitable for", options: ["Students", "Working Professionals", "Both"] },
  { key: "curfew", label: "Curfew timing" },
  { key: "visitors", label: "Visitors allowed", options: ["Yes", "No"] },
  { key: "smoking", label: "Smoking allowed", options: ["Yes", "No"] },
  { key: "alcohol", label: "Alcohol allowed", options: ["Yes", "No"] },
];
const airbnbFields: AdditionalField[] = [
  { key: "stay_type", label: "Short-stay property type", options: ["Entire Apartment", "Private Room", "Studio Apartment", "Villa", "Other"] },
  { key: "guests", label: "Guest capacity", type: "number" },
  { key: "bedrooms", label: "Bedrooms", type: "number" },
  { key: "bathrooms", label: "Bathrooms", type: "number" },
  { key: "furnishing", label: "Furnishing", options: ["Unfurnished", "Semi-Furnished", "Fully Furnished"] },
  { key: "deposit", label: "Security deposit (INR)", type: "number" },
  { key: "minimum_stay", label: "Minimum stay (nights)", type: "number" },
  { key: "maximum_stay", label: "Maximum stay (nights)", type: "number" },
  { key: "check_in", label: "Check-in time", type: "time" },
  { key: "check_out", label: "Check-out time", type: "time" },
  { key: "cleaning", label: "Cleaning charges (INR)", type: "number" },
  { key: "rules", label: "House rules" },
];

export function additionalFields(category: string): AdditionalField[] {
  if (category === "Rental") return [...flatFields, ...rentalFields];
  if (category === "Resale") return [...flatFields, ...resaleFields];
  if (category === "PG") return pgFields;
  if (category === "Airbnb") return airbnbFields;
  return [];
}

export const sharingFields: AdditionalField[] = sharingTypes.flatMap((type, index) => [
  { key: `sharing_${index}_rent`, label: `${type}: rent per person (INR)`, type: "number" as const },
  { key: `sharing_${index}_deposit`, label: `${type}: security deposit (INR)`, type: "number" as const },
  { key: `sharing_${index}_units`, label: `${type}: available units`, type: "number" as const },
]);

export function amenitiesForCategory(category: string): string[] {
  if (category === "Rental" || category === "Resale") return FLAT_AMENITIES;
  if (category === "PG") return PG_AMENITIES;
  if (category === "Airbnb") return AIRBNB_AMENITIES;
  return [];
}

export function categoryLabel(category: ListingType): string {
  return { Rental: "Flat Rental", Resale: "Flat Resale", PG: "PG / Hostel", Airbnb: "Airbnb / Short Stay" }[category];
}
