import Link from "next/link";
import { connection } from "next/server";
import { createSupabaseServerClient } from "../lib/supabase-server";
import { propertySubmissionsEnabled, propertySubmissionUploadsReady } from "../lib/property-submission-config";
import SubmissionForm from "./SubmissionForm";
import ResubmitForm from "./ResubmitForm";
import { validateSubmissionDetails, type SubmissionDetails } from "../lib/submission-details";
import { additionalFields, commonFields, sharingFields } from "./additional-fields";

export const instant = false;

type Submission = {
  id: string;
  title: string;
  category: string;
  locality: string;
  address: string;
  price: number;
  area: number;
  description: string;
  status: string;
  rejection_feedback: string | null;
  details: unknown;
};

function readableDetails(value: unknown): SubmissionDetails | null {
  if (value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 0) {
    return { version: 1, values: {}, amenities: {}, facilities: [] };
  }
  try { return validateSubmissionDetails(value); } catch { return null; }
}

function DetailsView({ details, submission }: { details: SubmissionDetails; submission: Submission }) {
  const labels = new Map<string, string>();
  for (const field of commonFields) labels.set(`common_${field.key}`, field.label);
  for (const category of ["Rental", "Resale", "PG", "Airbnb"]) {
    for (const field of additionalFields(category)) labels.set(`${category}_${field.key}`, `${category}: ${field.label}`);
  }
  for (const field of sharingFields) labels.set(`PG_${field.key}`, field.label);
  return <details className="mt-3"><summary className="min-h-11 cursor-pointer py-3 font-semibold">View saved details</summary>
    <dl className="mt-2 space-y-1 text-sm">
      <div><dt className="inline font-semibold">Address: </dt><dd className="inline whitespace-pre-wrap">{submission.address}</dd></div>
      <div><dt className="inline font-semibold">Price: </dt><dd className="inline">{submission.price} INR</dd></div>
      <div><dt className="inline font-semibold">Carpet area: </dt><dd className="inline">{submission.area} sq. ft.</dd></div>
      <div><dt className="inline font-semibold">Description: </dt><dd className="inline whitespace-pre-wrap">{submission.description}</dd></div>
    </dl>
    <dl className="mt-2 space-y-1 text-sm">{Object.entries(details.values).map(([key, value]) => <div key={key}><dt className="inline font-semibold">{labels.get(key)}: </dt><dd className="inline whitespace-pre-wrap">{value}</dd></div>)}</dl>
    {Object.entries(details.amenities).map(([category, items]) => items.length > 0 && <p key={category} className="mt-2 text-sm"><strong>{category} amenities:</strong> {items.join(", ")}</p>)}
    {details.facilities.length > 0 && <p className="mt-2 text-sm"><strong>PG facilities:</strong> {details.facilities.join(", ")}</p>}
  </details>;
}
export default async function ListPropertyPage() {
  await connection();
  const supabase = await createSupabaseServerClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError && authError.name !== "AuthSessionMissingError") {
    console.error("[property-submission] Authentication check failed", { name: authError.name });
    return <main className="mx-auto max-w-3xl bg-white p-4 text-slate-950 [overflow-wrap:anywhere] sm:p-8"><h1 className="text-2xl font-bold">List Your Property</h1><p role="alert" className="mt-3 text-rose-700">Your session could not be verified. Please try again or sign in again.</p><Link className="mt-4 inline-flex min-h-11 items-center underline" href="/account">Customer login or signup</Link></main>;
  }
  if (authError || !user) {
    return <main className="mx-auto max-w-3xl bg-white p-4 text-slate-950 [overflow-wrap:anywhere] sm:p-8"><h1 className="text-2xl font-bold">Sign in to list a property</h1><p className="mt-3">Sign in or create a Customer account to submit a property.</p><Link className="mt-4 inline-flex min-h-11 items-center underline" href="/account">Customer login or signup</Link></main>;
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profileError || !profile) {
    console.error("[property-submission] Profile lookup failed", { code: profileError?.code });
    return <main className="mx-auto max-w-3xl bg-white p-4 text-slate-950 [overflow-wrap:anywhere] sm:p-8"><p role="alert">Your Customer profile could not be verified. Please try again.</p><Link href="/account" className="mt-4 inline-flex min-h-11 items-center underline">My account</Link></main>;
  }
  if (profile.role !== "customer") {
    return <main className="mx-auto max-w-3xl bg-white p-4 text-slate-950 [overflow-wrap:anywhere] sm:p-8"><p role="alert">A Customer account is required to list a property here.</p><Link href="/account" className="mt-4 inline-flex min-h-11 items-center underline">Customer login or signup</Link></main>;
  }

  if (!propertySubmissionsEnabled()) {
    return <main className="mx-auto max-w-3xl bg-white p-4 text-slate-950 [overflow-wrap:anywhere] sm:p-8"><h1 className="text-3xl font-bold text-[#10243A]">List Your Property</h1><p role="status" className="mt-4 text-amber-800">Property submissions are awaiting private database setup. Nothing will be saved.</p><div className="mt-6"><SubmissionForm available={false} /></div><Link href="/account" className="mt-4 inline-flex min-h-11 items-center underline">My account</Link></main>;
  }

  const { data, error } = await supabase
    .from("property_submissions")
    .select("id,title,category,locality,address,price,area,description,status,rejection_feedback,details")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });
  if (error) console.error("[property-submission] Listing lookup failed", { code: error.code });
  const setupMissing = error?.code === "42P01" || error?.code === "PGRST205";
  const submissions: Submission[] = data ?? [];

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-[#10243A] px-4 py-4 text-white sm:px-6"><div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3"><Link href="/" className="inline-flex min-h-11 items-center font-bold tracking-widest">NAREN <span className="ml-1 text-amber-400">REALTY</span></Link><Link href="/account" className="inline-flex min-h-11 items-center rounded-lg border border-white/30 px-3 text-sm font-semibold">My account</Link></div></header>
      <section className="mx-auto max-w-6xl px-4 py-8 [overflow-wrap:anywhere] sm:px-6">
        <h1 className="text-3xl font-bold text-[#10243A]">List Your Property</h1>
        <div className="mt-6 grid min-w-0 gap-6 lg:grid-cols-2">
          <SubmissionForm available={!error && propertySubmissionUploadsReady()} unavailableMessage={error ? (setupMissing ? undefined : "Your submissions could not be loaded. Please try again; nothing will be saved.") : "New submissions are unavailable until private photo handling is ready. Nothing will be saved."} />
          <section className="min-w-0 rounded-xl border border-slate-200 bg-white p-4 sm:p-6">
            <h2 className="text-xl font-bold text-[#10243A]">My submissions</h2>
            {error ? <p role="alert" className="mt-4 text-sm text-rose-700">{setupMissing ? "Submissions are awaiting database setup." : "Your submissions could not be loaded. Please try again."}</p> : submissions.length === 0 ? <p className="mt-4 text-sm text-slate-600">You have not submitted any properties yet.</p> : <ul className="mt-4 space-y-3">{submissions.map((submission) => {
              const details = readableDetails(submission.details);
              return <li key={submission.id} className="rounded-lg border border-slate-200 p-4"><h3 className="font-bold">{submission.title}</h3><p className="text-sm text-slate-600">{submission.category} · {submission.locality}</p><p className="mt-2 text-sm font-semibold">Status: {submission.status === "pending" ? "Pending" : submission.status === "approved" ? "Approved" : submission.status === "rejected" ? "Rejected" : "Unknown"}</p>{details ? <DetailsView details={details} submission={submission} /> : <p role="alert">Saved details could not be read; editing is disabled to prevent data loss.</p>}{submission.status === "rejected" && submission.rejection_feedback && <p className="mt-2 whitespace-pre-wrap text-sm">Admin feedback: {submission.rejection_feedback}</p>}{submission.status === "rejected" && details && <ResubmitForm submission={{ ...submission, details }} available={propertySubmissionUploadsReady()} />}</li>;
            })}</ul>}
          </section>
        </div>
      </section>
    </main>
  );
}
