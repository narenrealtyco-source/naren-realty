"use client";

import { startTransition, useActionState, useEffect, useRef, useState, type FormEvent } from "react";
import { submitProperty, type SubmissionState } from "./actions";
import { MAX_SUBMISSION_PHOTO_BYTES, SUBMISSION_CATEGORIES, validatePropertySubmission, validateSubmissionPhotoCount } from "../lib/property-submission-validation";
import { categoryLabel } from "./additional-fields";
import AdditionalDetails, { emptyDetails } from "./AdditionalDetails";
import { validateSubmissionDetails } from "../lib/submission-details";
import type { ListingType } from "../lib/properties";
import SavedDetails from "./SavedDetails";

type Preview = {
  title: string; category: ListingType; locality: string; address: string;
  price: number; area: number; description: string;
  images: { url: string; name: string }[];
};

const initialState: SubmissionState = { status: "idle", message: "" };
const inputClass = "mt-2 block w-full rounded-lg border border-slate-400 bg-white px-4 py-3 text-base font-normal text-slate-950 placeholder:text-slate-600 focus:border-amber-700 focus:outline-2 focus:outline-amber-600";
const labelClass = "block text-sm font-semibold text-slate-900";

export default function SubmissionForm({ available, unavailableMessage }: { available: boolean; unavailableMessage?: string }) {
  const formRef = useRef<HTMLFormElement>(null);
  const attemptId = useRef<string | null>(null);
  const [category, setCategory] = useState("");
  const [details, setDetails] = useState(emptyDetails);
  const [detailError, setDetailError] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [state, action, pending] = useActionState(async (previous: SubmissionState, data: FormData): Promise<SubmissionState> => {
    try {
      const result = await submitProperty(previous, data);
      if (result.status === "success") {
        formRef.current?.reset();
        setCategory("");
        setDetails(emptyDetails());
        attemptId.current = null;
        setPreview(null);
      }
      return result;
    } catch (error) {
      console.error("[property-submission] Request failed", error);
      return { status: "error", message: "The submission could not be confirmed. Check your submissions before retrying." };
    }
  }, initialState);

  useEffect(() => () => { preview?.images.forEach((image) => URL.revokeObjectURL(image.url)); }, [preview]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try { validateSubmissionDetails(details); setDetailError(""); }
    catch (error) { setDetailError(error instanceof Error ? error.message : "Additional details are invalid."); return; }
    const data = new FormData(event.currentTarget);
    if (!preview) {
      try {
        const values = validatePropertySubmission({
          title: data.get("title"), category: data.get("category"), locality: data.get("locality"),
          address: data.get("address"), price: Number(data.get("price")), area: Number(data.get("area")),
          description: data.get("description"),
        });
        const files = data.getAll("photos");
        validateSubmissionPhotoCount(files.length);
        if (files.some((file) => !(file instanceof File) || file.size === 0 || file.size > MAX_SUBMISSION_PHOTO_BYTES ||
          !["image/jpeg", "image/png", "image/webp"].includes(file.type))) {
          throw new Error("Choose 1–5 JPEG, PNG or WebP photos, each up to 5 MB.");
        }
        const images = files.filter((file): file is File => file instanceof File)
          .map((file) => ({ url: URL.createObjectURL(file), name: file.name }));
        setPreview({ ...values, images });
      } catch (error) {
        setDetailError(error instanceof Error ? error.message : "The property could not be previewed.");
      }
      return;
    }
    if (!attemptId.current) attemptId.current = crypto.randomUUID();
    data.set("submission_id", attemptId.current);
    startTransition(() => action(data));
  }

  return (
    <form ref={formRef} onSubmit={handleSubmit} onChangeCapture={() => setPreview(null)} className="min-w-0 space-y-8 rounded-xl border border-slate-300 bg-white p-4 text-slate-950 shadow-sm sm:p-7">
      <div>
        <p className="text-xs font-bold tracking-[0.16em] text-amber-800">NAREN REALTY · PROPERTY DETAILS</p>
        <h2 className="mt-2 text-2xl font-bold text-[#10243A]">List your property</h2>
        <p className="mt-2 text-sm leading-6 text-slate-700">Your submission and photos remain private while awaiting review. If approved, the property details, full address and photos will be visible on the website.</p>
      </div>

      <fieldset className="min-w-0 space-y-4">
        <legend className="text-lg font-bold text-[#10243A]">Property overview</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className={labelClass}>Property category<select name="category" required value={category} onChange={(event) => setCategory(event.target.value)} className={inputClass}><option value="" disabled>Select a category</option>{SUBMISSION_CATEGORIES.map((item) => <option key={item} value={item}>{categoryLabel(item)}</option>)}</select></label>
          <label className={labelClass}>{category === "PG" ? "PG / Hostel name" : "Property title"}<input name="title" required maxLength={120} placeholder="e.g. Spacious apartment" className={inputClass} /></label>
          <label className={`${labelClass} sm:col-span-2`}>Property description<textarea name="description" rows={4} required maxLength={2000} placeholder="Describe the property" className={inputClass} /></label>
        </div>
      </fieldset>

      <fieldset className="min-w-0 space-y-4 border-t border-slate-200 pt-6">
        <legend className="text-lg font-bold text-[#10243A]">Location and pricing</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className={labelClass}>Locality<input name="locality" required maxLength={120} placeholder="e.g. Wakad" className={inputClass} /></label>
          <label className={labelClass}>{category === "Rental" ? "Monthly rent (INR)" : category === "Resale" ? "Expected sale price (INR)" : category === "Airbnb" ? "Price per night (INR)" : category === "PG" ? "Price per person (INR)" : "Price (INR)"}<input name="price" type="number" min="0.01" max="1000000000000" step="any" required placeholder="Enter price" className={inputClass} /></label>
          <label className={`${labelClass} sm:col-span-2`}>Full property address<textarea name="address" rows={2} required maxLength={500} placeholder="Enter the full address" className={inputClass} /></label>
          <label className={labelClass}>Carpet area (sq. ft.)<input name="area" type="number" min="0.01" max="10000000" step="any" required placeholder="Enter area" className={inputClass} /></label>
        </div>
      </fieldset>

      <AdditionalDetails category={category} details={details} onChange={setDetails} />
      {detailError && <p role="alert" className="text-sm font-semibold text-rose-800">{detailError}</p>}

      <fieldset className="min-w-0 space-y-3 border-t border-slate-200 pt-6">
        <legend className="text-lg font-bold text-[#10243A]">Property photos</legend>
        <label className={labelClass}>Upload photos<input name="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple required className="mt-2 block min-w-0 w-full max-w-full text-sm text-slate-900 file:mr-3 file:rounded-md file:border-0 file:bg-[#10243A] file:px-4 file:py-2 file:font-semibold file:text-white" /></label>
        <p className="text-sm leading-6 text-slate-700">Choose 1–5 JPEG, PNG or WebP photos, up to 5 MB each.</p>
      </fieldset>

      {preview && <section aria-label="Property preview" className="min-w-0 rounded-xl border border-amber-300 bg-amber-50 p-4 [overflow-wrap:anywhere]">
        <h3 className="text-lg font-bold text-[#10243A]">Review your property</h3>
        <p className="mt-2 font-semibold">{preview.title} · {categoryLabel(preview.category)}</p>
        <p className="mt-2 text-sm">{preview.locality} · ₹{preview.price.toLocaleString("en-IN")} · {preview.area} sq. ft.</p>
        <p className="mt-2 whitespace-pre-wrap text-sm">Address: {preview.address}</p>
        <p className="mt-2 whitespace-pre-wrap text-sm">{preview.description}</p>
        <SavedDetails value={details} />
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">{preview.images.map((image, index) => <img key={image.url} src={image.url} alt={`Selected photo ${index + 1}: ${image.name}`} width={320} height={240} className="aspect-[4/3] w-full rounded-lg object-cover" />)}</div>
        <p className="mt-3 text-sm text-slate-700">Changes to the form will require a new preview.</p>
      </section>}
      {state.message && <p role={state.status === "error" ? "alert" : "status"} className={state.status === "error" ? "text-sm font-semibold text-rose-800" : "text-sm font-semibold text-emerald-800"}>{state.message}</p>}
      {!available && <p role="status" className="text-sm font-semibold text-amber-900">{unavailableMessage ?? "Private submission setup is not yet verified. Nothing will be saved."}</p>}
      <button disabled={pending || (Boolean(preview) && !available)} className="w-full rounded-lg bg-[#10243A] px-5 py-3 text-base font-semibold text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-600 sm:w-auto">{pending ? "Submitting securely..." : preview ? "Submit for review" : "Preview property"}</button>
    </form>
  );
}
