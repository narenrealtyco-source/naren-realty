"use client";

import { startTransition, useActionState, useState, type FormEvent } from "react";
import { resubmitProperty, type SubmissionState } from "./actions";
import { SUBMISSION_CATEGORIES } from "../lib/property-submission-validation";
import { validateSubmissionDetails, type SubmissionDetails } from "../lib/submission-details";
import AdditionalDetails from "./AdditionalDetails";

type Values = {
  id: string; title: string; category: string; locality: string; address: string;
  price: number; area: number; description: string; details: SubmissionDetails;
};

const initialState: SubmissionState = { status: "idle", message: "" };
const inputClass = "mt-1 block min-w-0 w-full max-w-full rounded-md border border-slate-300 bg-white px-3 py-3 text-base font-normal";

export default function ResubmitForm({ submission, available }: { submission: Values; available: boolean }) {
  const [category, setCategory] = useState(submission.category);
  const [details, setDetails] = useState(submission.details);
  const [detailError, setDetailError] = useState("");
  const [state, action, pending] = useActionState(async (previous: SubmissionState, data: FormData): Promise<SubmissionState> => {
    try {
      return await resubmitProperty(previous, data);
    } catch (error) {
      console.error("[property-submission] Resubmission request failed", { errorType: error instanceof Error ? error.name : typeof error });
      return { status: "error", message: "Resubmission could not be confirmed. Refresh your submissions before retrying." };
    }
  }, initialState);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try { validateSubmissionDetails(details); setDetailError(""); }
    catch (error) { setDetailError(error instanceof Error ? error.message : "Additional details are invalid."); return; }
    const data = new FormData(event.currentTarget);
    startTransition(() => action(data));
  }
  return <details className="mt-4"><summary className="min-h-11 cursor-pointer py-3 font-semibold">Edit and resubmit</summary>
    <form onSubmit={submit} className="mt-3 space-y-3">
      <input type="hidden" name="submission_id" value={submission.id} />
      <label className="block text-sm font-semibold">Title<input name="title" defaultValue={submission.title} required maxLength={120} className={inputClass} /></label>
      <label className="block text-sm font-semibold">Category<select name="category" value={category} onChange={(event) => setCategory(event.target.value)} required className={inputClass}>{SUBMISSION_CATEGORIES.map((category) => <option key={category}>{category}</option>)}</select></label>
      <label className="block text-sm font-semibold">Locality<input name="locality" defaultValue={submission.locality} required maxLength={120} className={inputClass} /></label>
      <label className="block text-sm font-semibold">Full address<textarea name="address" defaultValue={submission.address} required maxLength={500} className={inputClass} /></label>
      <label className="block text-sm font-semibold">Price (INR)<input name="price" type="number" defaultValue={submission.price} min="0.01" max="1000000000000" step="any" required className={inputClass} /></label>
      <label className="block text-sm font-semibold">Carpet area (sq. ft.)<input name="area" type="number" defaultValue={submission.area} min="0.01" max="10000000" step="any" required className={inputClass} /></label>
      <label className="block text-sm font-semibold">Description<textarea name="description" defaultValue={submission.description} required maxLength={2000} className={inputClass} /></label>
      <AdditionalDetails category={category} details={details} onChange={setDetails} />
      {detailError && <p role="alert" className="text-sm text-rose-700">{detailError}</p>}
      <p className="text-sm text-slate-600">Existing private photos are retained; photo replacement is not available yet.</p>
      {!available && <p role="status" className="text-sm text-amber-900">Resubmission is unavailable until private submission setup is verified. Nothing will be saved.</p>}
      {state.message && <p role={state.status === "error" ? "alert" : "status"} className="text-sm">{state.message}</p>}
      <button disabled={pending || !available} className="min-h-11 w-full rounded-md bg-[#10243A] px-4 py-2 text-sm sm:w-auto font-semibold text-white disabled:opacity-50">{pending ? "Resubmitting..." : "Resubmit for review"}</button>
    </form>
  </details>;
}
